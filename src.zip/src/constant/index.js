export const API_URL_DATA_DB = "http://localhost:9000/dataDB"

export const API_URL_USERS_LIST_DB = "http://localhost:9001/usersListDB"